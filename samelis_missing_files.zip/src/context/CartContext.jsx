import { createContext, useContext, useState } from 'react'
const CartContext = createContext()
export const CartProvider = ({children}) => {
  const [cart,setCart]=useState([])
  const count = cart.reduce((s,i)=>s+(i.qty||1),0)
  return <CartContext.Provider value={{cart,setCart,count}}>{children}</CartContext.Provider>
}
export const useCart = () => useContext(CartContext)
